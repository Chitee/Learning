function validateAllData()
{
	alert("****************************************");
	var firstnameData=window.document.form1.txtName.value;
	var lastnameData=window.document.form1.txtLastName.value;
	var cityData=window.document.form1.txtState.value;
	var phoenData=window.document.form1.txtPhone.value;
	var emailData=window.document.form1.txtEmail.value;
	var dateData=window.document.form1.txtDate.value;
	var cityData=window.document.form1.txtstate.value;
	
	var state;
	
	
	if (cityData=="Chennai")
	{
		state =TamilNadu;
	}
	else if (cityData=="Mumbai")
	{
		state =Maharashtra;
	}
	else if (cityData=="Pune")
	{
		state =Maharashtra;
	}
	else
	{
		state =Karnataka;
	}
	
	var data = " First Name Is:  "+firstnameData + 
	"\n"+ "Last Name is: " + lastnameData + 
	"\n Contact Number is :" + phoenData +
	"\n Email Address is: " + emailData +
	"\n Date of Birth :" + dateData+ 
	"\n City:" + cityData
	"\n State :" + state;
	alert(data)
	
	var cgWindowObj =window.open(" " , "CgWindow" , "width=300, height= 300"); 
	cgWindowObj.document.write(data);
	/*alert (" Name Is:  "+nameData + 
	"\n"+ "Address:" + addressData + 
	"\n State :" + stateData +
	"\n Phone: " + phoenData +
	"\n Zip Code:" + postalCode+ 
	"\n Location:" + location);*/
	return true;	
}



