package com.cg.airspace.dto;

import java.io.Serializable;

public class UserPay implements Serializable
{
	
	private String mob;
	private String billAmt;
	private String billDate;
	
	public UserPay() {
		super();
	}

	public UserPay(String mob, String billAmt, String billDate) {
		super();
		this.mob = mob;
		this.billAmt = billAmt;
		this.billDate = billDate;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getBillAmt() {
		return billAmt;
	}

	public void setBillAmt(String billAmt) {
		this.billAmt = billAmt;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	@Override
	public String toString() {
		return "UserPay [mob=" + mob + ", billAmt=" + billAmt + ", billDate="
				+ billDate + "]";
	}
	
	
	
}
