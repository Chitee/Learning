package com.cg.airspace.dto;

import java.io.Serializable;

public class UserBean implements Serializable
{
	private String name;
	private String mob;
	private String userName;
	private String password;
	private String rePassword;
	
	public UserBean(String name, String mob, String userName, String password,
			String rePassword) {
		super();
		this.name = name;
		this.mob = mob;
		this.userName = userName;
		this.password = password;
		this.rePassword = rePassword;
	}

	public UserBean() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRePassword() {
		return rePassword;
	}

	public void setRePassword(String rePassword) {
		this.rePassword = rePassword;
	}

	@Override
	public String toString() {
		return "UserBean [name=" + name + ", mob=" + mob + ", userName="
				+ userName + ", password=" + password + ", rePassword="
				+ rePassword + "]";
	}
	
	
	
}
