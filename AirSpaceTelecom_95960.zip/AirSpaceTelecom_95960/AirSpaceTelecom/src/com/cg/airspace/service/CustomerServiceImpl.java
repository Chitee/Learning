package com.cg.airspace.service;

import com.cg.airspace.dao.CustomerDAO;
import com.cg.airspace.dao.CustomerDAOImpl;
import com.cg.airspace.dto.UserBean;
import com.cg.airspace.dto.UserPay;
import com.cg.airspace.exception.UserException;


public class CustomerServiceImpl implements CustomerService
{

	CustomerDAO userDao= new CustomerDAOImpl();
	
	@Override
	public void addUser(UserBean user) throws UserException {
		userDao.addUser(user);
		
	}

	@Override
	public void addAmount(UserPay pay) throws UserException {
		userDao.addAmount(pay);
		
	}
	
}
