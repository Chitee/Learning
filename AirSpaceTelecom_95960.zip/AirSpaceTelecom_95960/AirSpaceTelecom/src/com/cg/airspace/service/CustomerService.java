package com.cg.airspace.service;

import com.cg.airspace.dto.UserBean;
import com.cg.airspace.dto.UserPay;
import com.cg.airspace.exception.UserException;

public interface CustomerService 
{
	public void addUser(UserBean user) throws UserException;
	public void addAmount(UserPay pay) throws UserException;
}
