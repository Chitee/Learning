package com.cg.airspace.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cg.airspace.dto.UserBean;
import com.cg.airspace.dto.UserPay;
import com.cg.airspace.exception.UserException;
import com.cg.airspace.factory.DBUtil;


public class CustomerDAOImpl implements CustomerDAO
{

	@Override
	public void addUser(UserBean user) throws UserException {
		
		Connection con;
		try {
				con = DBUtil.getConnection();
				String query = "INSERT INTO users VALUES (?,?,?,?)";
				
				PreparedStatement ptmt = con.prepareStatement(query);
				
				ptmt.setString(1, user.getName());
				ptmt.setString(2, user.getUserName());
				
				
				ptmt.setString(3, user.getPassword());
				ptmt.setString(4, user.getMob());
				
				ptmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

	@Override
	public void addAmount(UserPay pay) throws UserException {
		// TODO Auto-generated method stub
		Connection con;
		try {
				con = DBUtil.getConnection();
				String query = "INSERT INTO bills VALUES (seq_bills.nextval,?,?,sysdate)";
				
				PreparedStatement ptmt = con.prepareStatement(query);
				
				ptmt.setString(1, pay.getMob());
				ptmt.setString(2, pay.getBillAmt());
				
				
				
				ptmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

}
