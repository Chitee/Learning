package com.cg.airspace.controller;



import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.airspace.dto.UserBean;
import com.cg.airspace.exception.UserException;
import com.cg.airspace.service.CustomerService;
import com.cg.airspace.service.CustomerServiceImpl;



/**
 * Servlet implementation class ProcessUser
 */
@WebServlet("/ProcessUser")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	CustomerService userSer;
    /**
     * Default constructor. 
     */
    public ProcessUser() {
        // TODO Auto-generated constructor stub
    	userSer = new CustomerServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession usersession = request.getSession(true);
		int fixAmount=750;
		
		switch(action)
		{
		case "add":
			{
				
				UserBean user=new UserBean();
			
				String name= request.getParameter("name");
				String mobileNo = request.getParameter("mobileNo");
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				String rePassword = request.getParameter("rePassword");
				
				if(password.equals(rePassword)){
				user.setName(name);
				user.setMob(mobileNo);
				user.setUserName(username);
				user.setPassword(password);
				user.setRePassword(rePassword);
				
				usersession.setAttribute("user", user);
				
				
				try {
					
				       userSer.addUser(user);
				       usersession.setAttribute("name", name);
				       usersession.setAttribute("mob", mobileNo);
					   RequestDispatcher rd=request.getRequestDispatcher("customerHome.jsp");
						rd.forward(request, response);
						
				} catch (UserException e) {
					
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
				}else{
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					rd.forward(request, response);
				}
				
			}
			break;
			
		case "addAmount":
		{
			com.cg.airspace.dto.UserPay pay=new com.cg.airspace.dto.UserPay();
			
			Object object = usersession.getAttribute("user");
			UserBean user = (UserBean) object;
			String amount = request.getParameter("payArea");
			
			
			pay.setMob(user.getMob());
			pay.setBillAmt(amount);
			
			
			
			int balanceAmount=fixAmount - Integer.parseInt(amount);
			
			try {
				
			       userSer.addAmount(pay);
				   RequestDispatcher rd=request.getRequestDispatcher("Success.jsp");
				   request.setAttribute("balanceAmount", balanceAmount);
				   request.setAttribute("amount", amount);
				   rd.forward(request, response);
					
			} catch (UserException e) {
				
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
			
			
		 }
		 break;
		
		
		
		}
	}
}
