DROP TABLE users cascade constraints;
CREATE TABLE users(
name VARCHAR2(40),
user_name VARCHAR2(40) PRIMARY KEY, 
password VARCHAR2(15), 
mobile_number VARCHAR2(12)
);
 
CREATE TABLE bills(
bill_id NUMBER(6) PRIMARY KEY, 
mobile_number VARCHAR2(12), 
bill_amt NUMBER(5),  
bill_date DATE
);
 
CREATE SEQUENCE seq_bills;