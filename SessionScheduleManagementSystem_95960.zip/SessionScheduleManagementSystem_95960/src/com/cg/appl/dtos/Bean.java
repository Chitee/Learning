package com.cg.appl.dtos;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="abc")
@Table(name="scheduledsessions")
public class Bean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int id;
	
	private String sessionName;
	
	private int duration;
	
	private String faculty;
	
	private String mode;
	
	
	public Bean() {
		super();
	}

	public Bean(int id, String sessionName, int duration, String faculty,
			String mode, String update) {
		super();
		this.id = id;
		this.sessionName = sessionName;
		this.duration = duration;
		this.faculty = faculty;
		this.mode = mode;
		
	}

	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="name")
	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	@Column(name="duration")
	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Column(name="faculty")
	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	@Column(name="mode1")
	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	

	
	@Override
	public String toString() {
		return "Bean [id=" + id + ", sessionName=" + sessionName
				+ ", duration=" + duration + ", faculty=" + faculty + ", mode="
				+ mode + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + duration;
		result = prime * result + ((faculty == null) ? 0 : faculty.hashCode());
		result = prime * result + id;
		result = prime * result + ((mode == null) ? 0 : mode.hashCode());
		result = prime * result
				+ ((sessionName == null) ? 0 : sessionName.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bean other = (Bean) obj;
		if (duration != other.duration)
			return false;
		if (faculty == null) {
			if (other.faculty != null)
				return false;
		} else if (!faculty.equals(other.faculty))
			return false;
		if (id != other.id)
			return false;
		if (mode == null) {
			if (other.mode != null)
				return false;
		} else if (!mode.equals(other.mode))
			return false;
		if (sessionName == null) {
			if (other.sessionName != null)
				return false;
		} else if (!sessionName.equals(other.sessionName))
			return false;
		
		return true;
	}
	
	
	
	
}
