package com.cg.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.appl.dtos.Bean;

@Repository("abcDao")
public class TrainingDAOImpl implements TrainingDAO {
	
	private static final long serialVersionUID = 1L;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Bean getSchedule(int id) {
		Bean emp= entityManager.find(Bean.class, id);
		return emp;
	}

	@Override
	public List<Bean> getAllSchedules() {
		TypedQuery<Bean> qry = entityManager.createQuery("SELECT s FROM abc s", Bean.class);
		return qry.getResultList();
	}

}
