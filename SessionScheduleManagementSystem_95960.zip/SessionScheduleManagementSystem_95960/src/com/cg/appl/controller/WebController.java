package com.cg.appl.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.appl.dtos.Bean;
import com.cg.appl.services.TrainingService;

@Controller
public class WebController {
	
	@Resource(name="abcServices")
	private TrainingService service;
	
	@RequestMapping(value="/listAll")
	public String seeAllRecords(Model model){
		
			System.out.println("In listSchedule");
			List<Bean> list= service.getAllSchedules();
			
			model.addAttribute("listSch",list);
			
			return "listSchedules";
		
		
	}
	
	@RequestMapping(value="/scheduleDetails")
	public String getScheduleDetails(@RequestParam("id") int schId, Model model ) {
		
			System.out.println(schId);
			
			Bean schedule=service.getSchedule(schId);
			System.out.println(schedule);
		
			model.addAttribute("schedule",schedule);
			model.addAttribute("Role",new String[]{"ILT","VC","WBT"});
			
			return "updateSchForm";
	
		
	}
	
	/*@RequestMapping(value="/updateSchedule", method=RequestMethod.POST)
	public String postScheduleData(@ModelAttribute("schedule") @Valid Bean schedule, BindingResult result, Model model){
		
			if(result.hasErrors()){
				
				//model.addAttribute("post",new String[]{"executive","assistant","associate"});
				return "updateEmpForm";
				
			}
			else{
			
			//boolean isUpdated=service.updateSchedule(schedule);
			//System.out.println("Is employee updated?" +isUpdated);
			
			return "updateEmpForm";
		
		}
		
		
	}*/
}
