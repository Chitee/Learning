package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.cg.appl.daos.TrainingDAO;
import com.cg.appl.dtos.Bean;

@Service("abcServices")
@Transactional
public class TrainingServiceImpl implements TrainingService {

private static final long serialVersionUID = 1L;
	
	@Resource(name="abcDao")
	private TrainingDAO dao;
	
	@Override
	public Bean getSchedule(int id) {
		
		return dao.getSchedule(id);
	}

	@Override
	public List<Bean> getAllSchedules() {
		
		return dao.getAllSchedules();
	}
	
}
