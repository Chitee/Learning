package com.cg.appl.services;

import java.io.Serializable;
import java.util.List;

import com.cg.appl.dtos.Bean;

public interface TrainingService extends Serializable{
	Bean getSchedule(int id);
	List<Bean> getAllSchedules();
}
